<?php
// PDO connection parameters
$host = 'db'; // The name of the database service in the Docker Compose file
$database = 'netland';
$username = 'mysql';
$password = 'mysql';

try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);

    // Set PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


    // Get the driver name
    $driver = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
    $version = $pdo->getAttribute(PDO::ATTR_SERVER_VERSION);


    // Display the driver name
    echo "Connected to db $database using the $driver driver version: $version.";
} catch (PDOException $e) {
    // Handle any errors that occurred during PDO connection
    echo 'Connection failed: ' . $e->getMessage();
}
?>
